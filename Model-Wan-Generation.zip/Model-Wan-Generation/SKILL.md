---
name: Model-Wan-Generation
description: Use when the user wants to generate video with the Alibaba Wan video model family — Wan 2.2, Wan 2.5, Wan 2.6, Wan 2.7, Wan 3.0, and Wan 3.0 Prime — covering text-to-video and image-to-video across 720p/1080p and durations from 2s up to 30s. Triggers on "Wan", "Wan 2.2", "Wan 2.5", "Wan 2.6", "Wan 2.7", "Wan 3.0", "Wan 3.0 Prime", "Wan video", "Alibaba Wan", "通义万相", or any request to select among Wan model tiers by resolution/duration. Do not use for built-in text_to_video / image_to_video tools (route those to creative-video); this skill is specifically for routing and generating with the Wan model family via API/inference endpoint and requires selecting the correct model tier for the requested resolution and duration.
---
# Geração de Vídeo com Família Wan (Alibaba)
Gera vídeo selecionando o modelo Wan correto conforme resolução e duração desejadas. Cobre seis modelos: **Wan 2.2**, **Wan 2.5**, **Wan 2.6**, **Wan 2.7**, **Wan 3.0** e **Wan 3.0 Prime**. Cada modelo tem limites rígidos de resolução e duração — a seleção errada causa falha na geração ou degradação da qualidade.

## Matriz de Modelos (resolução × duração)
| Modelo | Resolução máxima | Duração suportada | Tier | Uso ideal |
|---|---|---|---|---|
| **Wan 2.2** | 720p | 5s (fixo) | Entry / rápido | Previews, drafts, storyboard motion check, teste de prompt |
| **Wan 2.5** | 1080p | 5s–10s | Padrão | Social media (Reels/TikTok/Shorts), conteúdo geral, iteração balanceada |
| **Wan 2.6** | 1080p | 5s–15s | Padrão+ | Micro-cenas com começo-meio-fim, anúncios curtos, brand content |
| **Wan 2.7** | 1080p | 2s–15s | Cinemático / motion aprimorado | Cinemagraphs, loops, transições, motion design, clipes curtos de alta qualidade |
| **Wan 3.0** | 1080p | 2s–30s | Flagship | Narrativas longas, multi-beat, cenas complexas, entrega final |
| **Wan 3.0 Prime** | 1080p | 2s–30s | Flagship+ / máxima fidelidade | Entrega final cinematográfica, comerciais, brand films, máxima qualidade de motion e detalhe |

### Regra de Seleção Obrigatória
Sempre selecione o modelo **pelo par (resolução, duração)** solicitado, nunca por nome apenas:
1. Se o usuário pedir **720p** → só **Wan 2.2** serve (e duração fixa em 5s).
2. Se pedir **1080p e ≤10s** → escolha entre Wan 2.5 (econômico) ou superior; padrão = Wan 2.5.
3. Se pedir **1080p e 10–15s** → Wan 2.6 ou 2.7; padrão = Wan 2.6 (2.7 se houver ênfase em motion/cinemático).
4. Se pedir **duração <5s (2–4s)** → só Wan 2.7 / 3.0 / 3.0 Prime suportam; padrão = Wan 2.7.
5. Se pedir **>15s até 30s** → só **Wan 3.0** ou **Wan 3.0 Prime**; padrão = Wan 3.0 (Prime se o usuário pedir qualidade máxima/final).
6. Se o usuário não especificar, infira pelo caso de uso e **declare a escolha no resumo de confirmação**.

Nunca prometa 1080p com Wan 2.2, nem 30s com Wan 2.5/2.6/2.7. Se o pedido exceder o limite do modelo escolhido, explique e proponha upgrade de tier ou divisão em clipes.

## Limites Rígidos (não exceder)
- **Resolução**: Wan 2.2 → apenas 720p. Todos os demais (2.5+) → 1080p nativo. Não force resolução superior à suportada.
- **Duração** (em segundos, inteiro):
  - Wan 2.2: exatamente **5**
  - Wan 2.5: **5–10**
  - Wan 2.6: **5–15**
  - Wan 2.7: **2–15**
  - Wan 3.0: **2–30**
  - Wan 3.0 Prime: **2–30**
- **Proporções suportadas**: `16:9`, `9:16`, `1:1`, `4:3`, `3:4`, `21:9` (verificar disponibilidade por tier; 21:9 geralmente disponível a partir de 2.6+).
- **Modos**: Text-to-Video (T2V) e Image-to-Video (I2V / first-frame) em todos os tiers. R2V (referência múltipla) e áudio nativo podem variar — confirmar disponibilidade no endpoint antes de prometer.
- **Máximo de 2 vídeos por resposta** (regra global). Se o usuário pedir mais, gere 2 agora e avise que o restante sai na próxima interação. Nunca encadeie batches silenciosos para burlar o limite.

## Fluxo de Trabalho
1. **Identificar intenção e modo**: T2V (só texto) ou I2V (com imagem de referência/first frame).
2. **Selecionar modelo** pela matriz resolução×duração acima. Se houver ambiguidade, proponha o tier padrão e mencione alternativas.
3. **Clarificar e resumir parâmetros** antes de gerar — sempre, mesmo que tudo pareça definido:
   - Modelo Wan selecionado (nome + motivo)
   - Modo: T2V / I2V
   - Duração (em segundos, dentro do limite do modelo)
   - Resolução (720p / 1080p)
   - Proporção
   - Prompt final (texto da geração)
   - Imagens de referência, se houver (com papel de cada uma)
   Aguarde confirmação explícita: `confirmar`, `gerar`, `pode gerar`, `start`, `yes`, `looks good`. Respostas curtas como `ok` após um novo requisito **não contam** como confirmação.
4. **Preparar referências locais**: qualquer imagem no VM deve ser inspecionada com `Read` e enviada via `FileBatchUpload` antes de ser passada como URL. Nunca passe caminhos locais (`/home/user/...`) para a API.
5. **Gerar**: chamar o endpoint/ferramenta de inferência Wan com os parâmetros confirmados. Se usar ferramenta nativa `text_to_video`/`image_to_video`, mapear o tier Wan para o parâmetro de modelo correspondente.
6. **Entregar**: todo vídeo gerado deve ser exibido via `NotifyHuman` com URL renderizável ou caminho absoluto local. Só então declare sucesso. Se a geração falhar, reporte o erro com clareza e proponha ajuste (ex.: reduzir duração, fazer upgrade de tier).

Resumo de confirmação padrão:
```
Confirme os parâmetros antes de gerar:
- Modelo: Wan X.X (escolhido porque resolução=Y e duração=Zs)
- Modo: T2V / I2V (first frame)
- Duração: Xs  |  Resolução: 720p/1080p  |  Proporção: 16:9...
- Prompt: <texto final>
- Referências: <lista com papel de cada uma, ou "nenhuma">
Após confirmação, eu inicio a geração.
```

## Seleção por Caso de Uso (quick reference)
| Cenário | Modelo recomendado | Por quê |
|---|---|---|
| Preview rápido / teste de prompt / storyboard | Wan 2.2 | 720p 5s, mais rápido e barato |
| TikTok/Reels/Shorts (até 10s) | Wan 2.5 | 1080p, equilíbrio qualidade×velocidade |
| Anúncio curto / micro-cena (até 15s) | Wan 2.6 | 1080p até 15s, bom para narrativa curta |
| Cinemagraph / loop / motion design (2–4s) | Wan 2.7 | Suporta durações curtas, motion cinematográfico |
| Vídeo longo / multi-beat (até 30s) | Wan 3.0 | Único tier (junto com Prime) que chega a 30s |
| Entrega final / comercial / brand film | Wan 3.0 Prime | Máxima fidelidade, detalhe e estabilidade de motion |

## Tratamento de Conflitos e Limites
- **Usuário pede 1080p mas só quer 5s**: Wan 2.5+ serve; não use Wan 2.2 (que é só 720p).
- **Usuário pede 30s mas quer econômico**: só Wan 3.0/3.0 Prime chegam a 30s. Explique que 2.6/2.7 param em 15s e ofereça: (a) Wan 3.0 em 30s, ou (b) dois clipes de 15s com Wan 2.6 para concatenar depois.
- **Usuário pede 2–4s**: só Wan 2.7 em diante. Não tente Wan 2.5/2.6 com duração abaixo de 5s — eles não suportam.
- **I2V com imagem de proporção diferente da saída**: prefira manter a proporção da imagem de entrada; se o usuário insistir em mudar, explique que pode haver crop/distorção.
- **Geração >30s**: nenhum modelo Wan desta família suporta clipe único >30s. Proponha geração segmentada + pós-edição, ou explique o limite.

## Arquivos de Referência (leia conforme necessidade)
- `references/model-matrix.md` — detalhes completos por modelo: especificações técnicas, pontos fortes, pontos fracos, velocidade relativa, custo, e casos de uso recomendados com exemplos.
- `references/prompt-guide.md` — como escrever prompts eficazes para a família Wan: estrutura de prompt, tags de movimento de câmera, controle de personagem/produto via referências, anti-deriva (IP/produto), e dicas específicas por tier (2.2 vs 3.0 Prime).

## Entrega
Todo vídeo gerado deve ser exibido ao usuário via `NotifyHuman` (URL pública ou caminho absoluto do arquivo local). Nunca entregue apenas um `task_id` ou link cru como se fosse o resultado final. Inclua no texto final: modelo usado, duração, resolução, e uma observação breve sobre qualidade/limitações observadas.
