# Model Matrix — Família Wan (Alibaba)
Detalhes completos por modelo: especificações técnicas, pontos fortes, pontos fracos, velocidade relativa, custo e casos de uso recomendados.

## 1. Wan 2.2
- **Tier:** Entry / rápido / econômico
- **Resolução:** 720p (não suporta 1080p)
- **Duração:** 5s (fixo — não aceita outros valores)
- **Modos:** T2V, I2V (first-frame)
- **Proporções:** 16:9, 9:16, 1:1, 4:3, 3:4
- **Pontos fortes:** geração mais rápida da família, menor custo, bom para iterar prompts e validar motion rapidamente, boa estabilidade de movimento básico.
- **Pontos fracos:** resolução limitada a 720p, detalhes finais suaves, texto em cena instável, menos faixa de estilização, motion complexo (multi-personagem, física avançada) apresenta artefatos.
- **Velocidade:** Mais rápida (~30–90s por clipe)
- **Custo:** Mais baixo
- **Melhor para:** previews, storyboard animatics, teste A/B de prompts, rascunhos em lote, conteúdo onde 720p é suficiente (mobile-first).
- **Não use para:** entrega final 1080p, comerciais, cenas com texto legível, motion complexo.

## 2. Wan 2.5
- **Tier:** Padrão / equilibrado
- **Resolução:** 1080p nativo
- **Duração:** 5s–10s (inteiro)
- **Modos:** T2V, I2V (first-frame)
- **Proporções:** 16:9, 9:16, 1:1, 4:3, 3:4, 21:9 (verificar endpoint)
- **Pontos fortes:** primeiro tier com 1080p nativo, bom equilíbrio qualidade×velocidade, física de movimento sólida, boa renderização de materiais (tecido, metal, água), estabilidade de rosto/personagem aceitável.
- **Pontos fracos:** limitado a 10s (não serve para narrativas longas), detalhes extremos ainda abaixo de 3.0, ocasional flicker temporal em cenas com iluminação complexa.
- **Velocidade:** Média (~1–3 min por clipe)
- **Custo:** Médio-baixo
- **Melhor para:** social media (TikTok/Reels/Shorts), conteúdo de marca geral, anúncios curtos, clipes de produto, iteração de qualidade intermediária.
- **Não use para:** clipes >10s, entrega cinematográfica de máxima qualidade.

## 3. Wan 2.6
- **Tier:** Padrão+ / micro-narrativa
- **Resolução:** 1080p nativo
- **Duração:** 5s–15s (inteiro)
- **Modos:** T2V, I2V (first-frame), possivelmente R2V (confirmar endpoint)
- **Proporções:** 16:9, 9:16, 1:1, 4:3, 3:4, 21:9
- **Pontos fortes:** 1080p até 15s, permite começo-meio-fim em um único clipe, melhor coerência temporal que 2.5, texto em cena mais legível, bom para transições e micro-narrativas.
- **Pontos fracos:** não suporta durações abaixo de 5s (não faz cinemagraphs de 2–4s), qualidade de detalhe ainda abaixo de 2.7/3.0, motion de câmera complexo (órbita + dolly simultâneos) pode instabilizar.
- **Velocidade:** Média (~2–4 min por clipe)
- **Custo:** Médio
- **Melhor para:** anúncios de 10–15s, micro-cenas narrativas, brand content, demonstrações de produto com fluxo completo, clipes para YouTube/TV.
- **Não use para:** loops/cinemagraphs curtos (<5s), clipes >15s.

## 4. Wan 2.7
- **Tier:** Cinemático / motion aprimorado / duração flexível
- **Resolução:** 1080p nativo
- **Duração:** 2s–15s (inteiro) — primeiro tier a suportar <5s
- **Modos:** T2V, I2V (first-frame), R2V (confirmar)
- **Proporções:** 16:9, 9:16, 1:1, 4:3, 3:4, 21:9
- **Pontos fortes:** suporte a durações muito curtas (2–4s) ideal para cinemagraphs, loops e motion design; qualidade cinematográfica de motion e iluminação; melhor física (fogo, água, fumaça, tecido); estabilidade de câmera superior; ampla faixa de estilização (anime → fotorreal → 3D).
- **Pontos fracos:** limitado a 15s (não chega a 30s), custo mais alto que 2.5/2.6, geração mais lenta.
- **Velocidade:** Média-lenta (~3–6 min por clipe)
- **Custo:** Médio-alto
- **Melhor para:** cinemagraphs, loops perfeitos, motion design, transições criativas, clipes curtos de alta qualidade, aberturas, stingers, conteúdo artístico.
- **Não use para:** clipes >15s, previews econômicos.

## 5. Wan 3.0
- **Tier:** Flagship / longa duração
- **Resolução:** 1080p nativo (com melhor nitidez que tiers anteriores)
- **Duração:** 2s–30s (inteiro)
- **Modos:** T2V, I2V (first-frame), R2V, áudio nativo (confirmar endpoint)
- **Proporções:** 16:9, 9:16, 1:1, 4:3, 3:4, 21:9
- **Pontos fortes:** duração estendida até 30s (permite múltiplos beats narrativos em um clipe), melhor coerência multi-personagem, física avançada, iluminação cinematográfica, texto em cena estável, menor deriva de personagem/IP ao longo do clipe, bom para narrativa completa.
- **Pontos fracos:** geração mais lenta, custo mais alto, clipes de 20–30s podem apresentar leve deriva temporal no final — recomenda-se prompt com estado final claro.
- **Velocidade:** Lenta (~4–8 min por clipe; mais longo em 30s)
- **Custo:** Alto
- **Melhor para:** narrativas longas, comerciais completos, brand films, cenas complexas com múltiplos assuntos, conteúdo que exige >15s, entrega final de qualidade.
- **Não use para:** previews rápidos, testes de prompt (use 2.2).

## 6. Wan 3.0 Prime
- **Tier:** Flagship+ / máxima fidelidade
- **Resolução:** 1080p nativo (máxima nitidez e detalhe da família)
- **Duração:** 2s–30s (inteiro)
- **Modos:** T2V, I2V (first-frame), R2V, áudio nativo (confirmar endpoint)
- **Proporções:** 16:9, 9:16, 1:1, 4:3, 3:4, 21:9
- **Pontos fortes:** máxima qualidade de motion, detalhe e fidelidade da família; melhor estabilidade de rosto/mão/limbs; renderização de materiais hiper-realista; menor taxa de artefatos; ideal para entrega final e comerciais de alta produção; suporte a referências complexas.
- **Pontos fracos:** geração mais lenta da família, custo mais alto, overkill para previews e rascunhos.
- **Velocidade:** Mais lenta (~5–10 min por clipe)
- **Custo:** Mais alto
- **Melhor para:** entrega final cinematográfica, comerciais de TV/streaming, brand films, conteúdo premium, portfólio, qualquer caso onde a qualidade é o critério dominante.
- **Não use para:** testes de prompt, iteração rápida, conteúdo onde 720p/1080p básico é suficiente.

## Resumo Rápido de Comparação
| Modelo | Qualidade | Velocidade | Custo | Resolução | Duração | Motion Stability | Melhor Para |
|--------|-----------|------------|-------|-----------|---------|------------------|-------------|
| Wan 2.2 | ★★ | Mais rápida | Mais baixo | 720p | 5s fixo | ★★★ | Previews, drafts, testes |
| Wan 2.5 | ★★★ | Média | Médio-baixo | 1080p | 5–10s | ★★★★ | Social, geral, equilíbrio |
| Wan 2.6 | ★★★½ | Média | Médio | 1080p | 5–15s | ★★★★ | Micro-narrativa, anúncios 10–15s |
| Wan 2.7 | ★★★★ | Média-lenta | Médio-alto | 1080p | 2–15s | ★★★★½ | Cinemagraphs, motion design, curtos premium |
| Wan 3.0 | ★★★★½ | Lenta | Alto | 1080p | 2–30s | ★★★★★ | Narrativa longa, multi-beat, >15s |
| Wan 3.0 Prime | ★★★★★ | Mais lenta | Mais alto | 1080p | 2–30s | ★★★★★+ | Entrega final, comercial, máxima qualidade |

## Guia de Upgrade de Tier
Quando um pedido excede o limite do modelo atual, faça upgrade nesta ordem:
- Precisa de mais resolução (720p→1080p): Wan 2.2 → Wan 2.5
- Precisa de mais duração (≤10s→≤15s): Wan 2.5 → Wan 2.6
- Precisa de duração <5s: Wan 2.5/2.6 → Wan 2.7
- Precisa de >15s até 30s: Wan 2.6/2.7 → Wan 3.0
- Precisa de qualidade máxima/final: qualquer → Wan 3.0 Prime
