# Guia de Prompts — Família Wan (Alibaba)
Como escrever prompts eficazes para todos os tiers Wan, com dicas específicas por modelo.

## Estrutura Eficaz de Prompt
Construa em torno de cinco elementos visíveis: **(1) assunto + aparência detalhada → (2) cenário com luz e material → (3) ação/movimento principal → (4) movimento de câmera → (5) estado final claro**.

Template:
```
[Assunto + aparência detalhada] em [cenário com luz, material e atmosfera],
[ação/movimento principal concreto], [movimento de câmera],
[estado final / encerramento]. [Áudio: diálogo / voz / ambiente, se suportado].
```

Exemplo:
```
Uma ceramista em avental de linho bege, mãos cobertas de argila, moldando um vaso
em torno de roda de oleiro em ateliê com luz natural lateral de janela alta;
a argila sobe formando gargalo estreito, câmera [push in] lenta aproximando das
mãos; terminando com o vaso completo e a ceramista sorrindo. Ambiente: som suave
da roda e chuva leve na janela.
```

## Tags de Movimento de Câmera
Insira diretamente no texto, logo após a descrição chave. Use **apenas uma tag por tomada** — câmeras múltiplas geram instabilidade, especialmente em Wan 2.2/2.5.

| Tag | Efeito | Tier recomendado |
|-----|--------|------------------|
| `[static]` | Câmera fixa | Todos (mais estável em 2.2) |
| `[pan]` | Panorâmica horizontal | Todos |
| `[tilt]` | Vertical para cima/baixo | 2.5+ |
| `[zoom in]` / `[zoom out]` | Zoom óptico | Todos |
| `[push in]` / `[pull out]` | Aproxima/afasta com dolly | 2.6+ (melhor em 2.7/3.0) |
| `[tracking]` | Acompanha o sujeito | 2.6+ |
| `[dolly]` | Movimento de carrinho | 2.7+ |
| `[orbit]` | Órbita ao redor do sujeito | 2.7+ (evite em 2.2/2.5) |
| `[crane up]` | Grua vertical | 3.0 / 3.0 Prime |

## Dicas Específicas por Tier

### Wan 2.2 (720p, 5s)
- Mantenha o prompt curto e objetivo (≤150 palavras). Prompts longos degradam a qualidade.
- Um único movimento, um único assunto. Evite multi-personagem.
- Evite texto em cena — ilegível em 720p.
- Use `[static]` ou `[pan]` para máxima estabilidade.
- Perfeito para validar composição e motion antes de gerar em tier superior.

### Wan 2.5 (1080p, 5–10s)
- Prompt moderado (≤250 palavras).
- Suporta bem 1–2 assuntos e interação simples.
- Texto em cena curto (1–2 palavras) pode funcionar.
- Duração ideal: 5–8s para máxima qualidade; 10s começa a mostrar deriva no final.

### Wan 2.6 (1080p, 5–15s)
- Permite micro-narrativa: estabeleça início, desenvolvimento e desfecho no prompt.
- Use frases de transição: "começa com...", "em seguida...", "terminando com...".
- Texto em cena mais estável — títulos e slogans curtos funcionam.
- Para 15s, inclua um estado final explícito para evitar deriva.

### Wan 2.7 (1080p, 2–15s)
- Excelente para cinemagraphs e loops: especifique "loop perfeito" ou "movimento contínuo que retorna ao estado inicial".
- Para 2–4s, foque em um único movimento cinematográfico (ex.: "cortina se abrindo", "café sendo servido").
- Suporta motion de câmera complexo: `[orbit]`, `[dolly]`, `[tracking]`.
- Física avançada: fogo, água, fumaça, tecido — descreva o comportamento desejado.

### Wan 3.0 / 3.0 Prime (1080p, 2–30s)
- Para clipes >15s, estruture em beats narrativos claros (2–3 beats máximo).
- Repita âncoras de aparência no prompt para evitar deriva de personagem ao longo do tempo.
- Estado final obrigatório e detalhado — em 30s, o modelo pode "perder o rumo" sem um destino claro.
- 3.0 Prime: use prompts mais longos e descritivos (até ~400 palavras) — ele aproveita o detalhe.
- Para narrativa com diálogo (se áudio nativo disponível), escreva a fala entre aspas e indique tom/idioma.

## Controle via Referências (I2V / R2V)
Quando usar imagens de referência (first-frame ou multi-referência), **declare no prompt o que cada referência controla**, numerando-as como `@image1`, `@image2`:
- Aparência/roupa/rosto de personagem ou produto → `@image1` (repita âncoras visuais: cor, silhueta, acessórios, logo).
- Cenário/ambiente → `@image2`.
- Estilo/iluminação → `@image3`.

Exemplo: "A aparência da personagem segue @image1 (jaqueta jeans azul, cabelo cacheado, óculos redondo); o cenário segue @image2 (rua de paralelepípedo à noite com néon); o movimento é uma caminhada lenta em direção à câmera."

### Regras para I2V (first-frame)
- A proporção de saída tende a seguir a imagem de entrada — não force proporção diferente sem avisar o usuário sobre crop.
- Imagens nítidas ≥720p produzem resultados melhores; imagens borradas ou com texto são herdadas no resultado.
- O first-frame controla a abertura com exatidão — ideal para "dar vida" a uma imagem estática.

## Anti-Deriva (Personagens / Produtos / IP)
- Repita as âncoras de aparência **no corpo do prompt**, não confie apenas na imagem de referência.
- Para produtos: inclua nome, cor, formato, logotipo, ângulo e material.
- Para personagens: descreva cabelo, roupa, acessórios, tom de pele — e repita no final do prompt.
- Evite múltiplos personagens com falas/ações longas em clipes curtos (5–8s) — o risco de borrão/deriva aumenta.
- Texto em tela (títulos, legendas, slogans longos) é instável em todos os tiers; prefira pós-produção se precisar de legenda exata.
- Em clipes >15s (Wan 3.0/Prime), adicione uma frase de reforço no final: "a personagem mantém a mesma aparência e roupa durante todo o clipe".

## Escolha de Duração por Conteúdo
| Duração | O que cabe | Tier mínimo |
|---------|-----------|-------------|
| 2–4s | Um único movimento/efeito, cinemagraph, loop | Wan 2.7 |
| 5s | Uma ação completa com começo e fim | Wan 2.2 (720p) / 2.5 (1080p) |
| 8–10s | Micro-cena com um beat narrativo | Wan 2.5 |
| 12–15s | Narrativa curta com 2 beats, anúncio completo | Wan 2.6 / 2.7 |
| 20–30s | Narrativa longa com 2–3 beats, comercial completo | Wan 3.0 / 3.0 Prime |

## Proporção por Plataforma
- `9:16` — Reels/TikTok/Shorts/Stories
- `16:9` — YouTube/TV/desktop
- `1:1` — Feed Instagram/LinkedIn
- `4:3` — Retrô, retrato, alguns feeds
- `3:4` — Reels/retrato, Pinterest
- `21:9` — Cinemascope, brand films (confirmar suporte no tier; disponível a partir de 2.5+ na maioria dos endpoints)

## Erros Comuns a Evitar
1. **Prompt vago** ("um vídeo legal de praia") — sempre inclua assunto, ação, cenário, luz, câmera e estado final.
2. **Muitos assuntos em clipe curto** — cada personagem adicional reduz a estabilidade.
3. **Múltiplos movimentos de câmera** — um por tomada.
4. **Prometer 1080p com Wan 2.2** — ele é 720p apenas.
5. **Pedir 30s com Wan 2.6** — ele para em 15s; use Wan 3.0/Prime ou divida em clipes.
6. **Ignorar estado final** — especialmente em clipes longos, o modelo precisa de um destino.
7. **Texto longo em cena** — instável em todos os tiers; use pós-produção.
